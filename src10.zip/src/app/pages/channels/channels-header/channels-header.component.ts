import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channels-header',
  templateUrl: './channels-header.component.html',
  styleUrls: ['./channels-header.component.scss'],
})
export class ChannelsHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
