import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-business',
  templateUrl: './small-business.page.html',
  styleUrls: ['./small-business.page.scss'],
})
export class SmallBusinessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
