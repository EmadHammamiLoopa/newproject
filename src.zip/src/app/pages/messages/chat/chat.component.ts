import { Location } from '@angular/common';
import { ToastService } from './../../../services/toast.service';
import { WebView } from '@ionic-native/ionic-webview/ngx';
import { UploadFileService } from './../../../services/upload-file.service';
import { MessageService } from './../../../services/message.service';
import { User } from 'src/app/models/User';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from './../../../services/user.service';
import { Message } from './../../../models/Message';
import { Camera } from '@ionic-native/camera/ngx';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { IonContent, IonInfiniteScroll, Platform, AlertController } from '@ionic/angular';
import { SocketService } from 'src/app/services/socket.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/models/Product';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
})
export class ChatComponent implements OnInit {

  page = 0;
  resend = [];
  product: Product;
  productId: string;

  sentMessages = {};
  index = 0;

  image: string = null;
  imageFile: File = null;
  messageText = "";

  connected = false;
  @ViewChild('content') private content: IonContent;
  @ViewChild('infScroll') private infScroll: IonInfiniteScroll;

  messages: Message[] = [];
  socket: any;
  user: User;
  authUser: User;
  pageLoading = false;

  allowToChat = false;
  business = false;

  constructor(private camera: Camera, private userService: UserService, private route: ActivatedRoute,
              private messageService: MessageService, private changeDetection: ChangeDetectorRef,
              private platform: Platform, private uploadFileService: UploadFileService, private webView: WebView,
              private toastService: ToastService, private location: Location, private router: Router, private productService: ProductService, 
              private alertController: AlertController, private socketService: SocketService, private nativeStorage: NativeStorage) {
    this.socket = SocketService.socket; // Access static member correctly
  }

  ngOnInit() {
    console.log("ngOnInit called");
    this.getAuthUser();
    // Fetch product details from route parameters
    this.route.paramMap.subscribe(params => {
      const productId = params.get('id');
      console.log("Retrieved productId from route parameters:", params);
      if (productId) {
        this.productId = productId;
        this.getProductDetails(productId);
      } else {
        console.warn("No productId found in route parameters.");
      }
    });
  }

  ionViewWillEnter() {
    console.log("ionViewWillEnter called");
    this.pageLoading = true;
    this.getUserId();
    // Restore conversation state if necessary
    if (this.authUser && this.authUser.id) {
      this.initializeSocket();
      this.getMessages(null);
    }
  }

  getProductDetails(productId: string, event?) {
    if (!event) this.pageLoading = true;
    console.log("Fetching product details for productId:", productId);
    this.productService.get(productId).then(
      (resp: any) => {
        console.log("Product details response:", resp);
        this.pageLoading = false;
        this.product = new Product().initialize(resp.data);
        console.log("Initialized product:", this.product);
        if (event) event.target.complete();
      },
      err => {
        this.pageLoading = false;
        console.error("Error fetching product details:", err);
        if (event) event.target.complete();
        this.toastService.presentStdToastr(err);
      }
    );
  }

  getAuthUser() {
    console.log("getAuthUser called");
    this.pageLoading = true;
    this.nativeStorage.getItem('user')
      .then(
        user => {
          if (user) {
            console.log("User retrieved from NativeStorage:", user);
            this.authUser = new User().initialize(user);
            this.initializeSocket();
            this.getUserId();
          } else {
            console.warn("User data is undefined in NativeStorage, falling back to localStorage.");
            this.fallbackToLocalStorage();
          }
        },
        err => {
          console.error("Error retrieving user from NativeStorage, falling back to localStorage:", err);
          this.fallbackToLocalStorage();
        }
      );
  }

  fallbackToLocalStorage() {
    console.log("fallbackToLocalStorage called");
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      if (user) {
        console.log('User data retrieved from localStorage:', user);
        this.authUser = new User().initialize(user);
        console.log('User data retrieved from this.authUser:', this.authUser);
        this.initializeSocket();
        this.getUserId();
      } else {
        console.error('User data is undefined or null in localStorage');
        this.pageLoading = false;
      }
    } catch (err) {
      console.error('Error retrieving user from localStorage:', err);
      this.pageLoading = false;
    }
  }

  handleUserInitError() {
    this.pageLoading = false;
    this.router.navigate(['/login']);
  }

  getUserId() {
    console.log("getUserId called");
    // Check if authUser is initialized and has a valid _id
    if (this.authUser && this.authUser._id) {
      this.getUserProfile(this.authUser._id);
      console.log('User ID from authUser:', this.authUser._id);
    } else {
      // Fallback to route parameters if authUser is not initialized
      this.route.paramMap.subscribe(params => {
        const id = params.get('id');
        console.log("User ID from route parameters:", id);
        if (id) {
          this.getUserProfile(id);
        } else {
          console.error('User ID is missing in both authUser and route parameters');
          this.handleUserInitError();
        }
      });
    }
  }

  getUserProfile(userId: string) {
    console.log('Fetching user profile for userId:', userId);
    if (!userId) {
      console.error('User ID is undefined');
      this.pageLoading = false;
      return;
    }
    this.userService.getUserProfile(userId)
      .subscribe(
        (resp: any) => {
          console.log('Response from getUserProfile:', resp);
          if (resp && resp.data) {
            console.log('User profile data:', resp.data);
            this.user = new User().initialize(resp.data);
            this.getMessages(null);
          } else if (resp) {
            // Handling case if response structure is different
            console.log('User profile data:', resp);
            this.user = new User().initialize(resp);
            this.getMessages(null);
          } else {
            console.error('User profile data is undefined or null');
            this.pageLoading = false;
          }
        },
        err => {
          console.error('Error retrieving user profile:', err);
          this.pageLoading = false;
          this.toastService.presentStdToastr('Sorry, this user is not available');
          this.location.back();
        }
      );
  }

  initializeSocket() {
    console.log("initializeSocket called");
    if (this.socket && this.authUser && this.authUser.id) {
      this.page = 0;
      this.socket.emit('connect-user', this.authUser.id);
      this.initSocketListeners();
    } else {
      console.error('Socket or user ID is undefined');
    }
  }

  scrollToBottom() {
    this.content.scrollToPoint(0, 1000 * 1000);
  }

  getUser(id: string) {
    this.getUserProfile(id);
  }
  
  getMessages(event) {
    console.log("Fetching messages for user ID:", this.user.id);
    this.messageService.indexMessages(this.user.id, this.page++)
      .then(
        (resp: any) => {
          this.pageLoading = false;
          console.log("Messages response:", resp);

          if (!event) {
            this.messages = [...resp.data.messages.map(message => new Message().initialize(message)), ...this.messages];
          } else {
            event.target.complete();
            this.messages = [...this.messages, ...resp.data.messages.map(message => new Message().initialize(message))];
          }

          if (!resp.data.more) {
            this.infScroll.disabled = true;
          }

          console.log("Messages after fetch:", this.messages);

          this.allowToChat = resp.data.allowToChat;
        },
        err => {
          console.log("Error fetching messages:", err);
          this.pageLoading = false;
          this.toastService.presentStdToastr(err);
        }
      );
  }

  checkMessageExisting(message) {
    return this.messages.find(msg => msg.id == message._id) ? true : false;
  }

  initSocketListeners() {
    console.log("initSocketListeners called");
    if (this.socket) {
      this.socket.on('new-message', (message) => {
        console.log("New message received:", message);
        if (this.user && message.from == this.user.id && !this.checkMessageExisting(message)) {
          this.messages.push(new Message().initialize(message));
          this.changeDetection.detectChanges();
          setTimeout(() => {
            this.scrollToBottom();
          }, 200);
        }
      });

      this.socket.on('message-sent', (message, ind) => {
        console.log("Message sent confirmation received:", message);
        if (this.sentMessages[ind]) {
          this.sentMessages[ind].id = message._id;
          this.sentMessages[ind].state = 'sent';
          if (this.resend.includes(ind)) this.resend.splice(this.resend.indexOf(ind), 1);
        }

        this.sentMessages[ind] = undefined;
      });

      this.socket.on('message-not-sent', (ind) => {
        console.log("Message not sent:", ind);
        if (this.sentMessages[ind]) {
          this.sentMessages[ind].state = 'failed';
          if (this.resend.includes(ind)) this.resend.splice(this.resend.indexOf(ind), 1);
        }
      });
    } else {
      console.error('Socket is undefined, cannot initialize socket listeners');
    }
  }

  resendMessage(message) {
    this.resend.push(message.id);
    this.sendMessage(message, message.id);
  }

  getChatPermission() {
    return new Promise((resolve, reject) => {
      this.messageService.getPermission(this.user.id)
        .then(
          (resp: any) => {
            console.log('Chat permission response:', resp);
            if (resp.data) resolve(true);
            reject(true);
          },
          err => {
            console.error("Error fetching chat permission:", err);
            this.toastService.presentStdToastr(err);
            reject(false);
          }
        );
    });
  }

  sendMessage(message, ind) {
    console.log("Sending message:", message);
    this.socket.emit('send-message', {
      text: message.text,
      from: message.from,
      to: message.to,
    }, this.imageFile, ind);
  }

  addMessage() {
    console.log("Adding message with text:", this.messageText);
    if (!this.messageText && !this.imageFile) return;

    if (!this.conversationStarted()) {
      this.messageText = "";
      return;
    }

    this.getChatPermission().then(
      () => {
        const message = new Message();
        message.id = this.index.toString();
        message.from = this.authUser.id;
        message.to = this.user.id;
        message.text = this.messageText;
        message.state = '';
        message.createdAt = new Date();
        if (this.image) {
          message.image = this.image;
        }

        this.messages.push(message);
        this.sentMessages[this.index] = message;

        setTimeout(() => {
          this.scrollToBottom();
        }, 200);

        this.sendMessage(message, this.index++);

        this.messageText = "";
        this.image = null;
        this.imageFile = null;
      },
      err => {
        if (err) this.router.navigate(['/tabs/subscription']);
      }
    );
  }

  pickImage() {
    console.log("Picking image");
    this.uploadFileService.takePicture(this.camera.PictureSourceType.CAMERA)
      .then(
        (resp: any) => {
          if (window.cordova && this.webView) {
            this.image = this.webView.convertFileSrc(resp.imageData);
          } else {
            console.warn('Cordova is not available. Using raw image data.');
            this.image = resp.imageData; // Use raw image data as a fallback
          }
          this.imageFile = resp.file;
          this.addMessage();
        },
        err => {
          console.error('Error taking picture:', err);
        }
      );
  }

  allowToShowDate(ind: number): boolean {
    const currDate = {
      year: this.messages[ind].createdAt.toJSON().slice(0, 4),
      month: this.messages[ind].createdAt.toJSON().slice(5, 7),
      day: this.messages[ind].createdAt.toJSON().slice(8, 10)
    };
    if (ind) {
      const lastDate = {
        year: this.messages[ind].createdAt.toJSON().slice(0, 4),
        month: this.messages[ind].createdAt.toJSON().slice(5, 7),
        day: this.messages[ind].createdAt.toJSON().slice(8, 10)
      };

      return currDate.day != lastDate.day || currDate.month != lastDate.month
          || currDate.year != lastDate.year;
    }
    return true;
  }

  conversationStarted() {
    return (this.allowToChat || (this.messages && (this.messages.length <= 1 || this.messages.filter(msg => !msg.isMine(this.authUser.id)).length > 0)));
  }

  ProfileEnabled() {
    return this.allowToChat || (this.messages && (this.messages.filter(msg => !msg.isMine(this.authUser.id)).length > 0));
  }

  showUserProfile() {
    if (this.ProfileEnabled()) this.router.navigateByUrl('/tabs/profile/display/' + this.user.id);
    else this.lockedProfileAlert();
  }

  async lockedProfileAlert() {
    const alert = await this.alertController.create({
      header: 'Not Allowed',
      message: 'You can only access the profile after ' + this.user.fullName + ' respond to your messages',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    await alert.present();
  }

  videoCall() {
    if (this.authUser  && this.user) {
      this.router.navigateByUrl('/messages/video/' + this.user.id);
    } else this.videoCallSubAlert();
  }
  
  async videoCallSubAlert() {
    const message = !this.user.friend ? ('You can only call friends, how about sending a friend request to ' + this.user.fullName) : ('You must subscribe to call ' + this.user.fullName);
    const alert = await this.alertController.create({
      header: 'You can\'t call ' + this.user.fullName,
      message: message,
      buttons: [
        {
          text: 'cancel',
          role: 'cancel'
        },
        {
          text: 'Subscribe',
          cssClass: 'text-danger',
          handler: () => {
            this.router.navigateByUrl('/tabs/subscription');
          }
        }
      ]
    });
    await alert.present();
  }

  nonFriendsChatEnabled() {
    return (this.user && this.user.friend) || (this.messages.length < 10);
  }
}
