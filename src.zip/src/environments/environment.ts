export const environment = {
  production: false,
  apiUrl: 'https://newbackedn22.onrender.com/api/v1' // Replace with your computer's IP address
};
