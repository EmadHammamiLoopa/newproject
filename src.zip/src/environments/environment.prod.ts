export const environment = {
  production: true,
  apiUrl: 'https://newbackedn22.onrender.com/api/v1' // Replace with your computer's IP address
};
